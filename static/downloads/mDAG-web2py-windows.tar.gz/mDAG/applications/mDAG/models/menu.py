# -*- coding: utf-8 -*- 

#########################################################################
## Customize your APP title, subtitle and menus here
#########################################################################

response.title = 'mDAG'
response.subtitle = T('analysis of multiple-treatment microarray data')

##########################################
## this is the main application menu
## add/remove items as required
##########################################

response.menu = [(T('Home'), False, URL(request.application,'default','index'),
			[
			    (T('Downloads'), False, URL(request.application,'others','downloads'), []),
			    (T('Help'), False, URL(request.application,'others','help'), [])
			]
		)]
##########################################
## this is here to provide shortcuts
## during development. remove in production 
##
## mind that plugins may also affect menu
##########################################

response.menu += [(T('Data'), False, URL(request.application,'default','data'), [])]

response.menu += [(T('Analyze'), False, URL(request.application,'default','analyze'), [])]

response.menu += [(T('Results'), False, URL(request.application,'default','results'), [])]
