import os
import sys
import re
import gc

from datetime import datetime

import sqlite3
#import MySQLdb

from Methods import *

#Reading the arguments
Argument = []
Argument = sys.argv[1:]
app_folder = Argument[0]
result_id = Argument[1]


def Executer():

	"""
	Reading information
	This code reads dataset information, gene expression data file and other information
	"""

	db_path = os.path.join(app_folder, 'databases', 'storage.db')

	print "Reading information for result id: " + result_id

	try:
		#Connecting to database and reading information
                #con = MySQLdb.connect(host = "localhost", user = "mdat", passwd = "mdat", db = "mdat")
		con = sqlite3.connect(db_path)
		con.row_factory = sqlite3.Row
		c = con.cursor()

		c.execute('SELECT * FROM results WHERE id="' + result_id + '"')
		con.commit()

		result=c.fetchone()

		dataset_id=str(result['dataset_id'])
		c.execute('SELECT * FROM datasets WHERE id="' + dataset_id + '"')
		con.commit()

		dataset=c.fetchone()

		FDRrate = result['sign_level'] # False Discovery Rate for analysis

		rep_number = result['rep_number']
		temparr=[]
		temparr=rep_number.split("\n")
		nameoftreat=[]
		numofrep=[]

		for i in range(len(temparr)):
			temp=[]
			temp=temparr[i].split(" ")
			nameoftreat.append(temp[0])
			numofrep.append(int(temp[1]))

		numoftreat = (len(numofrep)) # Finding the number of treatments involved
		totalofrep = sum(numofrep)

		permutation = result['perm_number'] # permutation number for Monte Carlo method

                #Generating directories where result files will be stored
		file_name = dataset['file_name'] # Dataset file name
		file_path = os.path.join(app_folder, 'uploads', file_name)
		p = re.compile('.txt')
		dir_name = p.sub('', file_name)
		dir_path = os.path.join(app_folder, 'static', 'results') # path to the final directory in which a new directory with same name as input file will be created to hold the results.

		dir_path1 = os.path.join(dir_path, dir_name)
		if not os.path.isdir(dir_path1):
			os.mkdir(dir_path1)

		dir_name1 = str(FDRrate) + str(permutation)
		result_path = os.path.join(dir_path1, dir_name1)
		if not os.path.isdir(result_path):
			os.mkdir(result_path)

		c.close()
		con.close()
	except:
		print "Error for reading input parameters in Executer:", sys.exc_info()[0]
		return 0

	#Reading dataset file

	Header = [] #Header

	Probeset = [] #Probe ID

	Infoarray = [] #All information
	unigeneid = [] #UniGene ID
	genetitle = [] #Gene Title
	genesymbol = [] #Gene Symbol
	chromolocal = [] #Chromosomal Location
	reppubid = [] #Representative Public ID

	Expressionmatrix = [] #Expression data

	try:
		d = file(file_path).read()
	except IOError:                     
		print "Error for reading input file in Executer:", sys.exc_info()[0]
		return 0

	rowspre = d.split('\n')
	rows = []

	for l in rowspre:
		if l.strip():
		    rows.append(l)

	Header = rows[2].split('\t')
	NRows = len(rows) # number of rows in the dataset file

	Indexarray = range(totalofrep)
		
	for i in range(3,NRows):

		rowlist = []
		rowlist = rows[i].split('\t')
		
		Probeset.append(rowlist[0])

		try:
			Infoarray.append(rowlist[1])
			tempinfo =  rowlist[1].split("=")

			temparr =  tempinfo[0].split(" ")
			unigeneid.append(temparr[0])

			temparr =  tempinfo[2].split(" ")
			genesymbol.append(temparr[0])

			genetitle.append(tempinfo[1])
			chromolocal.append(tempinfo[3])
			reppubid.append(tempinfo[4])
		except:
			print "Error in reading gene information", sys.exc_info()[0]
			Infoarray.append("")
			unigeneid.append("")
			genesymbol.append("")
			genetitle.append("")
			chromolocal.append("")
			reppubid.append("")

		Expressionmatrix.append(map(float, rowlist[2:]))   # Storing Expression data as 2-D array 

		

	"""
	Analyzing data
	This code uses other modules to perform Kruskal Wallis Test, False discovery rate, calculate Pvalue using MonteCarlo Permutation, perform PostHocComparison and generates patterns.
	It also uses Graphviz software to generate .svg and .png files to show clusters in the form of graphs.
	"""

	print "Start selecting significant genes for result id: " + result_id

	"""
	Calculating H-statistics for the original data
	"""

	Hstatistics = [] 

	"""
	Calculating Hstatistics for the original or unpermuted data
	"""

	for j in range(0,len(Expressionmatrix)):  # Finding and storing Hstatistics, KWPvalue 
		Hstat = 0; 
		Hstat = KruskalWallisTest(Expressionmatrix[j], numofrep, Indexarray) 
		Hstatistics.append(Hstat)
	
	
	MonteCarloCounter = [0]*(len(Expressionmatrix)) 

	"""
	Calculating Hstatistics for Permuted data 
	"""
	from datetime import timedelta
	start = datetime.now()
	
	for p in range(permutation):

		print "Permutation " + str(p) + " of result id " + str(result_id)
		if p == 5:
			try:
				#Connect to database again
				#con = MySQLdb.connect(host = "localhost", user = "mdat", passwd = "mdat", db = "mdat")
				con = sqlite3.connect(db_path)
				c = con.cursor()
				unit_duration = datetime.now() - start
				unit_seconds = unit_duration.seconds
				total_minutes = int(permutation*unit_seconds/300) + 1
				c.execute('UPDATE results SET process_time=? WHERE id=?', (total_minutes, str(result_id)))
				con.commit()
				c.close()
				con.close()
			except:
				print "Error for updating database in Executer:", sys.exc_info()[0]
				return 0

		Indexarray = Permutation(Indexarray)

		for k in range(0,len(Expressionmatrix)): # Finding and storing Hstatistics, KWPvalue 
			Hstatp = 0
			Hstatp = KruskalWallisTest(Expressionmatrix[k], numofrep, Indexarray)
		
			if Hstatp >= Hstatistics[k]:
				MonteCarloCounter[k] = MonteCarloCounter[k]+1
			

	"""
	Calculating MonteCarloPvalue 
	"""

	MonteCarlopvalue = []

	for counter in MonteCarloCounter:
		MonteCarlopval = 0
		MonteCarlopval = float(1 + counter)/float(permutation + 1)
		MonteCarlopvalue.append(MonteCarlopval)


	"""
	Peforming FDR check for significant differentially expressed genes
	"""

	Significantpvalues = [] 

	Significantpvalues = FDRAnalysis(MonteCarlopvalue, FDRrate) 


	"""
	If there is no gene significantly differentially expressed, return
	"""

	if Significantpvalues == []:
		print "No gene is significantly differentially expressed"

		try:
			#Connect to database again
			#con = MySQLdb.connect(host = "localhost", user = "mdat", passwd = "mdat", db = "mdat")
			con = sqlite3.connect(db_path)
			c = con.cursor()

			timestamp = datetime.now()

			status_update_sql='UPDATE results SET finish_time=?, status=? WHERE id=?'

			c.execute(status_update_sql, (str(timestamp), "No gene is significantly differentially expressed", str(result_id)))
			con.commit()

			c.close()
			con.close()

			gc.collect()

		except:
			print "Error for updating database in Executer:", sys.exc_info()[0]
			return 0

		return 0


	"""
	If there are genes significantly differentially expressed, continue analyzing
	"""

	Uniquepvalues = []
	Uniquepvalues = unique(Significantpvalues)

	SignificantGenesindex = []

	for pvalue in Uniquepvalues:
		genearray = []
		genearray  = get_index_new(MonteCarlopvalue, pvalue)
		for genekey in genearray:
			SignificantGenesindex.append(genekey)


	print "Finish selecting significant genes for result id: " + result_id

	"""
	Peforming PostHoc testing and printing the Ternary Pattern for significant differentially expressed gene
	"""

	print "Start peforming post hoc comparisons for result id: " + result_id

	CombinationList = [] 
	for y in combinations(range(1,(numoftreat+1)),2): CombinationList.append(tuple(y))


	Patterndict = {}
	IndexPatterndict = {}

	for l in SignificantGenesindex:
		
	
		Pattern = ''
		Treatmentdic = {}
		left = right = 0
		count = 0

		for m in numofrep:
			right = right + m
			count = count+1
			Treatmentdic[count] = Expressionmatrix[l][left:right]
			left = right
		
		for (a,b) in CombinationList:
			Pvalue,PvalueC = RanksumComparison(Treatmentdic[a],Treatmentdic[b])

			if Pvalue < 0.05:
				Pattern = Pattern+str(2)
			elif PvalueC < 0.05:
				Pattern = Pattern+str(0)
			else:
				Pattern = Pattern+str(1)

		if Pattern in Patterndict:
			Patterndict[Pattern].append(Probeset[l])
			IndexPatterndict[Pattern].append(l)
		else:
			Patterndict[Pattern] = []
			IndexPatterndict[Pattern] = []

			Patterndict[Pattern].append(Probeset[l])
			IndexPatterndict[Pattern].append(l)


	Binarydict = {}

	for keys in Patterndict.keys():
		    Binarydict[int(keys)] = keys


	print "Finish peforming post hoc analysis for result id: " + result_id

	print "Start creating results for result id: " + result_id


	"""
	Creating overview graph
	"""

	Overviewclusters(SignificantGenesindex, Patterndict, numoftreat, numofrep, nameoftreat, FDRrate, result_path)


	"""
	Creating all graphical patterns for the first level cluster
	"""

	for pattern in Patterndict.keys():
		FirstLevelClusters(pattern, len(Patterndict[pattern]), numoftreat, nameoftreat, result_path)


	"""
	Creates gene files for all probesets
	"""

	for pattern in IndexPatterndict.keys():
		GeneListFiles(pattern, IndexPatterndict, Header, Probeset, Infoarray, numofrep, totalofrep, Expressionmatrix, MonteCarlopvalue, result_path)


	"""
	Creating all graphical patterns for the second level cluster
	"""

	Resultdict, Symboldict = SecondLevelClusterDictionary(nameoftreat, numoftreat, Patterndict)

	Sumdict = {}
	Totalsum = 0

	for a in Resultdict.keys():
		Sum = 0
		for b in Resultdict[a]:
			Sum = Sum + len(Patterndict[b])
			Totalsum = Totalsum + len(Patterndict[b])
	
		Sumdict[a] = Sum

		
	Contractratiodict = {}

	for second_cluster in Resultdict.keys():

		allpatterns = []
		Allpattern = {}
		allpatterns = Resultdict[second_cluster]
		contractiblecount = 0.0;

		for eachpattern in allpatterns:
			Allpattern[eachpattern] = len(Patterndict[eachpattern])
		if Contractibility(numoftreat,str(eachpattern)):
		    	contractiblecount = contractiblecount + len(Patterndict[eachpattern])

		Contractratio = float(contractiblecount)/float(Sumdict[second_cluster])
		Contractratiodict[second_cluster] = round(Contractratio,3)

		SecondLevelClusters(second_cluster, Allpattern, Contractratio, Resultdict, Symboldict, Sumdict, Patterndict, numoftreat, nameoftreat, result_path)


	"""
	Storing all results in database
	"""

	import cPickle
	
	Binarydict_string = cPickle.dumps(Binarydict, cPickle.HIGHEST_PROTOCOL)
	Patterndict_string = cPickle.dumps(Patterndict, cPickle.HIGHEST_PROTOCOL)
	IndexPatterndict_string = cPickle.dumps(IndexPatterndict, cPickle.HIGHEST_PROTOCOL)
	MonteCarlopvalue_string = cPickle.dumps(MonteCarlopvalue, cPickle.HIGHEST_PROTOCOL)

	Resultdict_string = cPickle.dumps(Resultdict, cPickle.HIGHEST_PROTOCOL)
	Symboldict_string = cPickle.dumps(Symboldict, cPickle.HIGHEST_PROTOCOL)
	Sumdict_string = cPickle.dumps(Sumdict, cPickle.HIGHEST_PROTOCOL)
	Contractratiodict_string = cPickle.dumps(Contractratiodict, cPickle.HIGHEST_PROTOCOL)
	
	try:
		#Connect to database again to store results
		#con = MySQLdb.connect(host = "localhost", user = "mdat", passwd = "mdat", db = "mdat")
		con = sqlite3.connect(db_path)
		con.text_factory = str
		c = con.cursor()

		#Set status to Completed
		timestamp = datetime.now()

		status_update_sql='UPDATE results SET finish_time=?, status=?, binary_dict=?, pattern_dict=?, index_pattern_dict=?, monte_carlo_pvalue=?, result_dict=?, symbol_dict=?, sum_dict=?, contract_dict=? WHERE id=?'

		c.execute(status_update_sql, (str(timestamp), "Completed", sqlite3.Binary(Binarydict_string), sqlite3.Binary(Patterndict_string), sqlite3.Binary(IndexPatterndict_string), sqlite3.Binary(MonteCarlopvalue_string), sqlite3.Binary(Resultdict_string), sqlite3.Binary(Symboldict_string), sqlite3.Binary(Sumdict_string), sqlite3.Binary(Contractratiodict_string), str(result_id)))

		con.commit()

		c.close()
		con.close()

	except:
		print "Error for updating database in Executer:", sys.exc_info()[0]
		return 0

	print "Finish analyzing result id: " + result_id
	gc.collect()


"""
Main program
"""
if __name__ == "__main__":

	Executer()

	"""
	Call Scheduler again after finish this analysis
	"""
	scheduler_path = os.path.join(app_folder, 'modules', 'Scheduler.py')
	cmd='python ' + scheduler_path + ' ' + app_folder + ' &'
	os.system(cmd)

	gc.collect()
	sys.exit()
