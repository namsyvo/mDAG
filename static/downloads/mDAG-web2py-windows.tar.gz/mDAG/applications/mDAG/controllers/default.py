import os
import sys
import re
from datetime import datetime

import cPickle
import sqlite3

Methods = local_import('Methods', reload = True) #reload = True for reloading when there is update with Methods file, if no, it still use the old version until the server will be restarted. It will be set to False when deploy the software for running faster

from gluon.tools import Crud

crud = Crud(globals(), db)


def index():
    return dict()

def user():
    return dict(form=auth())

def download():
    return response.download(request,db)

def call():
    session.forget()
    return service()


def dataset_remove():

	print len(request.vars.dataset)

	if request.vars.dataset!=None:
		if len(request.vars.dataset)==1:
			dataset = db(db.datasets.id == request.vars.dataset).select(db.datasets.file_name, db.datasets.ori_file_name)[0]
			ori_file_name = dataset.ori_file_name
			file_name = dataset.file_name
			p = re.compile('.txt')
			dir_name = p.sub('',file_name)
			file_path1 = os.path.join(request.folder, 'uploads', file_name)
			os.system('rm ' + file_path1)
			file_path2 = os.path.join(request.folder, 'static', 'results', dir_name)
			os.system('rm -r ' + file_path2)
			db(db.datasets.id == request.vars.dataset).delete()
			db.commit()
			return 'Removed: ' + str(ori_file_name)
		else:
			return_str = ''
			for dataset_id in request.vars.dataset:
				dataset = db(db.datasets.id == dataset_id).select(db.datasets.file_name, db.datasets.ori_file_name)[0]
				ori_file_name = dataset.ori_file_name
				file_name = dataset.file_name
				p = re.compile('.txt')
				dir_name = p.sub('',file_name)
				file_path1 = os.path.join(request.folder, 'uploads', file_name)
				os.system('rm ' + file_path1)
				file_path2 = os.path.join(request.folder, 'static', 'results', dir_name)
				os.system('rm -r ' + file_path2)
				db(db.datasets.id == dataset_id).delete()
				db.commit()
				return_str += str(ori_file_name)
				return_str += '<br />'
			return 'Removed: ' + return_str
	else:
		return 'Please choose a dataset to remove!'


def upload_processing(form):
    if request.vars.file_name != None:
        form.vars.ori_file_name = request.vars.file_name.filename

def data():

    datasets= db().select(db.datasets.ALL)

    if 'auth' in globals() and auth.user:
	db.datasets.username_id.default=auth.user.id
    else:
	db.datasets.username_id.default=1 #mDAG default user

    form=SQLFORM(db.datasets)
    # do all the corresponding form processing
    if form.accepts(request.vars, session, onvalidation = upload_processing):
        redirect(URL(r=request, f='analyze'))
        response.flash = 'Dataset is uploaded successfully!'
    elif form.errors:
        response.flash = 'There are some errors!'
    return dict(form=form, datasets=datasets)


def pre_analyze_processing(form):
    if request.vars.dataset_id != None:
	dataset= db(db.datasets.id == request.vars.dataset_id).select(db.datasets.rep_number)[0]
        form.vars.rep_number = dataset.rep_number

def analyze():

    form=SQLFORM(db.results)
    # do all the corresponding form processing
    if form.accepts(request.vars, session, onvalidation = pre_analyze_processing):
	file_path = os.path.join(request.folder, "modules", "Scheduler.py")
	print "C:\\Python27\\python " + file_path + " " + request.folder + " &"
	os.system("C:\\Python27\\python " + file_path + " " + request.folder + " &")
	redirect(URL(r=request, f='results'))
        response.flash = 'Request was submitted successfully!'
    elif form.errors:
        response.flash = 'There are some errors!'
    return dict(form=form)


import shutil

def results():

    if request.args(0)=='remove':
        result= db(db.results.id==request.args[1]).select(db.results.dataset_id, db.results.sign_level, db.results.perm_number)[0]
        dataset= db(db.datasets.id==result.dataset_id).select(db.datasets.file_name)[0]
	p = re.compile('.txt')
	dataset_dir_name = p.sub('', dataset.file_name)
	result_dir_name = str(result.sign_level) + str(result.perm_number)
	dir_path = os.path.join(request.folder, 'static', 'results', dataset_dir_name, result_dir_name)
	try:
	        shutil.rmtree(dir_path)
	except:
		print 'Error in deleting directories'
		pass
        db(db.results.id==request.args[1]).delete()
        db.commit()
        redirect(URL(r=request, f='results'))
        return dict()        

    else:
	if 'auth' in globals() and auth.user:
            results=db((db.results.dataset_id==db.datasets.id) & (db.datasets.username_id==auth.user.id)).select(db.datasets.id, db.datasets.username_id, db.datasets.file_name, db.datasets.ori_file_name, db.datasets.rep_number, db.datasets.upload_time, db.results.id, db.results.dataset_id, db.results.rep_number, db.results.sign_level, db.results.perm_number, db.results.upload_time, db.results.start_time, db.results.finish_time, db.results.status, db.results.process_time, orderby=~db.results.id)
            return dict(results=results)
	else:
            results=db((db.results.dataset_id==db.datasets.id) & (db.datasets.username_id==1)).select(db.datasets.id, db.datasets.username_id, db.datasets.file_name, db.datasets.ori_file_name, db.datasets.rep_number, db.datasets.upload_time, db.results.id, db.results.dataset_id, db.results.rep_number, db.results.sign_level, db.results.perm_number, db.results.upload_time, db.results.start_time, db.results.finish_time, db.results.status, db.results.process_time, orderby=~db.results.id)
            return dict(results=results)


def dataset():

    dataset = db(db.datasets.id == request.vars.id).select()[0]
    file_path = os.path.join(request.folder, 'uploads', dataset.file_name)

    try:
        d = file(file_path).read()
    except IOError:                     
        print 'The file does not exists.'
        return dict()

    number = []
    header = []
    rows = []
    rowspre = d.split('\n')
    for l in rowspre:
        if l.strip():
            rows.append(l)

    number = rows[1].split('\t')
    header = rows[2].split('\t')

    return dict(dataset = dataset, number = number, header = header)


#############################################################
#results
#############################################################

def treat_rep(rep_number):
    temparr=[]
    temparr=rep_number.split("\n")
    nameoftreat=[]
    numofrep=[]

    for i in range(len(temparr)):
        temp=[]
        temp=temparr[i].split(" ")
        nameoftreat.append(temp[0])
        numofrep.append(int(temp[1]))

    numoftreat = (len(numofrep)) # number of treatments

    return nameoftreat, numofrep, numoftreat


def overview():

    result = db(db.results.id == request.vars.id).select(db.results.id, db.results.dataset_id, db.results.sign_level, db.results.perm_number)[0]

    dataset = db(db.datasets.id == result.dataset_id).select(db.datasets.file_name)[0]

    p = re.compile('.txt')
    dataset_dir_name = p.sub('', dataset.file_name)
    result_dir_name = str(result.sign_level) + str(result.perm_number)

    graph_path = os.path.join('results', dataset_dir_name, result_dir_name, 'Unordered.svg')

    return dict(result = result, graph_path = graph_path)


def firstlevel():

    result= db(db.results.id == request.vars.id).select()[0]

    nameoftreat, numofrep, numoftreat = treat_rep(str(result.rep_number))

    binary_dict=cPickle.loads(str(result.binary_dict))
    pattern_dict=cPickle.loads(str(result.pattern_dict))

    return dict(result=result, numoftreat=numoftreat, nameoftreat=nameoftreat, binary_dict=binary_dict, pattern_dict=pattern_dict)


def secondlevel():

    result= db(db.results.id == request.vars.id).select()[0]

    result_dict=cPickle.loads(str(result.result_dict))
    symbol_dict=cPickle.loads(str(result.symbol_dict))
    sum_dict=cPickle.loads(str(result.sum_dict))
    contract_dict=cPickle.loads(str(result.contract_dict))

    return dict(result=result, result_dict=result_dict, symbol_dict=symbol_dict, sum_dict=sum_dict, contract_dict=contract_dict)


def metacluster():

    result = db(db.results.id == request.vars.id).select()[0]

    nameoftreat, numofrep, numoftreat = treat_rep(str(result.rep_number))

    pattern_dict = cPickle.loads(str(result.pattern_dict))
    result_dict = cPickle.loads(str(result.result_dict))
    symbol_dict = cPickle.loads(str(result.symbol_dict))

    dataset = db(db.datasets.id == result.dataset_id).select(db.datasets.file_name)[0]
    p = re.compile('.txt')
    dataset_dir_name = p.sub('', dataset.file_name)
    result_dir_name = str(result.sign_level) + str(result.perm_number)

    second_cluster = request.vars.sb
    
    graph_path = os.path.join('results', dataset_dir_name, result_dir_name, 'Firstlevel', 'Secondlevel', str(symbol_dict[second_cluster])+'scgraph.png')

    return dict(result = result, numoftreat = numoftreat, nameoftreat = nameoftreat, pattern_dict = pattern_dict, result_dict = result_dict, symbol_dict = symbol_dict, graph_path = graph_path)


import math
def pattern():

    result= db(db.results.id == request.vars.id).select()[0]

    nameoftreat, numofrep, numoftreat = treat_rep(str(result.rep_number))

    Header = [] #Dataset header
    Probeset = [] #Probeset ID
    Infoarray = [] #All information about gene
    unigeneid = [] #UniGene ID
    genetitle = [] #Gene title
    genesymbol = [] #Gene symbol
    chromolocal = [] #Chromosomal location
    reppubid = [] #Representative public ID
    Expressionmatrix = [] #Expression data

    dataset = db(db.datasets.id==result.dataset_id).select(db.datasets.file_name)[0]

    file_name = dataset.file_name
    p = re.compile('.txt')
    dataset_dir_name = p.sub('', dataset.file_name)
    result_dir_name = str(result.sign_level) + str(result.perm_number)

    pattern = request.vars.p

    graph_path = os.path.join('results', dataset_dir_name, result_dir_name, 'Firstlevel', pattern + 'graph.png')
    gene_file_path = os.path.join('results', dataset_dir_name, result_dir_name, 'Firstlevel', pattern + 'gene.txt')

    file_path = os.path.join(request.folder, 'uploads', file_name)

    try:
    	d = file(file_path).read()
    except IOError:
    	print "The file does not exists."
    	return dict()

    rowspre = d.split('\n')
    rows = []
    for l in rowspre:
        if l.strip():
            rows.append(l)

    NRows = len(rows) # number of rows in the dataset file

    Header = rows[2].split('\t')
		
    for i in range(3, NRows):
        rowlist = []
        rowlist = rows[i].split('\t')
    
        Probeset.append(rowlist[0])

	try:
		Infoarray.append(rowlist[1])
		tempinfo =  rowlist[1].split("=")

		temparr =  tempinfo[0].split(" ")
		unigeneid.append(temparr[0])

		temparr =  tempinfo[2].split(" ")
		genesymbol.append(temparr[0])

		genetitle.append(tempinfo[1])
		chromolocal.append(tempinfo[3])
		reppubid.append(tempinfo[4])
	except:
		print "Error in reading gene information", sys.exc_info()[0]
		Infoarray.append("")
		unigeneid.append("")
		genesymbol.append("")
		genetitle.append("")
		chromolocal.append("")
		reppubid.append("")

        Expressionmatrix.append(map(float, rowlist[2:]))


    index_pattern_dict=cPickle.loads(str(result.index_pattern_dict))
    monte_carlo_pvalue=cPickle.loads(str(result.monte_carlo_pvalue))
    
    NormL2values = {}
    NormL1values = {}
    NormL2probes = {}
    NormL1probes = {}
    
    for s in index_pattern_dict[pattern]:
    	NormL2v = NormL1v = 0
    	NormL2v = Methods.NormL2(Expressionmatrix[s])
    	NormL1v = Methods.NormL1(Expressionmatrix[s])
    	NormL2values[s] = NormL2v
    	NormL2probes[Probeset[s]] = NormL2v
    	NormL1values[s] = NormL1v
    	NormL1probes[Probeset[s]] = NormL1v
    	
    NormL2tuple = []
    NormL2tuple = Methods.sortbyvalue(NormL2values,reverse=True)
	
    genemania_list = ""
    david_list = ""
    gcat_list = ""

    temp_count = 0
	
    for index, magnitude in NormL2tuple:
        if temp_count < len(NormL2tuple)-1:
            genemania_list = genemania_list + str(genesymbol[int(index)]) + "|"
            david_list = david_list + str(Probeset[int(index)]) + ","
            gcat_list = gcat_list + str(genesymbol[int(index)]) + "+"
            
        else:
            genemania_list = genemania_list + str(genesymbol[int(index)])
            david_list = david_list + str(Probeset[int(index)])
            gcat_list = gcat_list + str(genesymbol[int(index)])

	temp_count = temp_count + 1

    Treat_Mean = []
    Treat_Quad_Mean = []
    for probeindex in index_pattern_dict[pattern]:
        mean = []
        quad_mean =[]
        currentPos = 0
        for i in range(0, numoftreat):
            s=0
            qs=0
            for j in range(currentPos, currentPos+numofrep[i]):
		s = s + Expressionmatrix[probeindex][j]
		qs = qs + Expressionmatrix[probeindex][j]**2
            mean.append(s/numofrep[i])
            quad_mean.append(math.sqrt(qs/numofrep[i]))
            currentPos = currentPos + numofrep[i]
        Treat_Mean.append(mean)
        Treat_Quad_Mean.append(quad_mean)

    Mean = []
    Quad_Mean = []
    for i in range(0,numoftreat):
        mean = 0
        quad_mean = 0
        gene_num = len(index_pattern_dict[pattern])
        for index in range(0, gene_num):
            mean = mean + Treat_Mean[index][i]
            quad_mean = quad_mean + Treat_Quad_Mean[index][i]
        Mean.append(mean/gene_num)
        Quad_Mean.append(quad_mean/gene_num)

    return dict(result = result, Probeset = Probeset, Infoarray = Infoarray, unigeneid = unigeneid, NormL1values = NormL1values, NormL2tuple = NormL2tuple, numoftreat = numoftreat, nameoftreat = nameoftreat, numofrep = numofrep, monte_carlo_pvalue = monte_carlo_pvalue, genemania_list = genemania_list, david_list = david_list, gcat_list = gcat_list, Mean = Mean, Quad_Mean = Quad_Mean, graph_path = graph_path, gene_file_path = gene_file_path)
