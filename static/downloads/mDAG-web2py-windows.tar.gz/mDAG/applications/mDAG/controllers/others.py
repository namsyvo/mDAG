# coding: utf8

def download():
    return response.download(request,db)

def downloads():
    datasets= db().select(db.sampledata.ALL, orderby=db.sampledata.id)
    return dict(datasets=datasets)

def help():
    return dict()
    
def comments():
    if 'auth' in globals():
        if auth.user:
            feedback = db(db.feedbacks.id==request.args(0)).select()[0]
            db.comments.feedback_id.default=feedback.id

            db.comments.username_id.default=auth.user.id
            db.comments.first_name.default=auth.user.first_name
            db.comments.last_name.default=auth.user.last_name

            form = SQLFORM(db.comments)

            if form.accepts(request.vars, session):
                response.flash = 'your comment is posted'
            elif form.errors:
                response.flash = 'There are some errors!'
            comments = db(db.comments.feedback_id==feedback.id).select()
            return dict(feedback=feedback, comments=comments, form=form)

    return dict()
