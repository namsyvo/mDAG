from gluon.admin import app_compile

app_compile(request.application, request)

## Run: python web2py.py -S yourappname -R compile.py 
