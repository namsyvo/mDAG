jQuery(document).ready(function(){jQuery('[multiple]').multiSelect({maxHeight:200});});
