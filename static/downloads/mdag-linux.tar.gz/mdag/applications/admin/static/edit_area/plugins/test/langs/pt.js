editArea.add_lang("pt",{
test_select: "select tag",
test_but: "test button"
});
